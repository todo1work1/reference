package main.java.com.todows.api;

import org.springframework.boot.SpringApplication;

@SprintBootApplication
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}
}
