package com.ews.api.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ews.api.entity.EmployeeTodo;
import com.ews.api.service.EmployeeTodoService;

@RestController
@RequestMapping("/api")
public class EmployeeTodoController {

	@Autowired
	private EmployeeTodoService employeeTodoService;
	
	@GetMapping("/employee/todos")
	public List<EmployeeTodo> getAllTodos() {
		
		return employeeTodoService.getAllTodos();
		
	}
	
	@PostMapping("/employee/todos")
	public boolean saveEEmployeeTodo(@RequestBody EmployeeTodo empTodo) {
		return employeeTodoService.saveTodo(empTodo);
	}
	
	@GetMapping("/employee/todo")
	public Optional<EmployeeTodo> getTodoById(@RequestParam("id") int id) {
		return employeeTodoService.getTodoById(id);
	}
	
	/*@GetMapping("/employee/todo")
	public EmployeeTodo getTodoById(@RequestParam("id") int id) {
		return employeeTodoService.getTodoById(id);
	}*/
}
