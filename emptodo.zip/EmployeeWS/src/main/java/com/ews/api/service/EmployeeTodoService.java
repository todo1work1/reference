package com.ews.api.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.ews.api.entity.EmployeeTodo;

@Service
public class EmployeeTodoService {

	static List<EmployeeTodo> employeeTodos = new ArrayList();
	static {
		/*{
    "UserId": 1,
    "Id": 20;
    "Title": "We have no freedom of choice to be wise"
    "Completed": true
  }
  {
    "UserId": 2,
    "Id": 21,
    "Title": "takes pains to meet some pleasure"
    "Completed" false
  }*/
		/*EmployeeTodo todo = new EmployeeTodo(1,20,"We have no freedom of choice to be wise", true);
		employeeTodos.add(todo);
		todo = new EmployeeTodo(2,21,"takes pains to meet some pleasure", false);
		employeeTodos.add(todo);*/
		EmployeeTodo todo = new EmployeeTodo(1,20,"We have no freedom of choice to be wise", true, new Date());
		employeeTodos.add(todo);
		todo = new EmployeeTodo(2,21,"takes pains to meet some pleasure", false, new Date());
		employeeTodos.add(todo);
	}
	
	public List<EmployeeTodo> getAllTodos() {
		return employeeTodos;
	}
	
	public boolean saveTodo(EmployeeTodo todo) {
		try {
			employeeTodos.add(todo);
		}catch(Exception e) {
			return false;
		}
		return true;
	}
	
	public Optional<EmployeeTodo> getTodoById(int id) {
		/*for(int i=0; i<employeeTodos.size(); i++ ) {
			EmployeeTodo todo = employeeTodos.get(i);
			if(todo.getId()==id) {
				return todo;
			}
		}
		return null;*/
		return employeeTodos.stream().filter(t -> t.getId()==id).findFirst();
	}
}
