package com.cms.api.entity;

import java.util.ArrayList;
import java.util.List;

public class Todos {

	private List<Todo> todoList = new ArrayList<>();

	public List<Todo> getTodoList() {
		return todoList;
	}

	public void setTodoList(List<Todo> todoList) {
		this.todoList = todoList;
	}

	public Todos(List<Todo> todoList) {
		super();
		this.todoList = todoList;
	}

	public Todos() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
