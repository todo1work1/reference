package com.cms.api.entity;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Todo {
	@JsonProperty(value="Userid")
	private int userId;
	@JsonProperty(value="TodoId")
	private int id;
	@JsonProperty(value="Title")
	private String title;
	private boolean completed;
	private Date completionDate;
	
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getId() {
		return id;
	}
	public Date getCompletionDate() {
		return completionDate;
	}
	public void setCompletionDate(Date completionDate) {
		this.completionDate = completionDate;
	}
	public Todo(int userId, int id, String title, boolean completed, Date completionDate) {
		super();
		this.userId = userId;
		this.id = id;
		this.title = title;
		this.completed = completed;
		this.completionDate = completionDate;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public boolean isCompleted() {
		return completed;
	}
	public void setCompleted(boolean completed) {
		this.completed = completed;
	}
	public Todo(int userId, int id, String title, boolean completed) {
		super();
		this.userId = userId;
		this.id = id;
		this.title = title;
		this.completed = completed;
	}
	public Todo() {
		super();
		// TODO Auto-generated constructor stub
	}
}
