package com.cms.api.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cms.api.entity.Todo;

@RestController
@RequestMapping("/api")
public class TodoController {

	@Autowired
	private RestTemplate restTemplate;
	
	/*@GetMapping("/todo")
	public ResponseEntity<String> defaultFunction() {
		ResponseEntity<String> response = restTemplate.exchange("http://localhost:8081/api/employee/todos", HttpMethod.GET, null, String.class);
		//return "It will fetch a list of todos from https://jsonplaceholder.typicode.com/todos" "http://dummy.restapiexample.com/api/v1/employees";
		return response;
	}*/
	
	/*@GetMapping("/todo")
	public ResponseEntity<List<Todo>> defaultFunction() {
		ResponseEntity<List<Todo>> response = restTemplate.exchange("http://localhost:8081/api/employee/todos",
				HttpMethod.GET, null, new ParameterizedTypeReference<List<Todo>>(){});
		//return "It will fetch a list of todos from https://jsonplaceholder.typicode.com/todos" "http://dummy.restapiexample.com/api/v1/employees";
		return response;
	}*/
	
	@PostMapping("/todo")
	public void saveTodo() {
		Todo todo = new Todo(4,64, "pleasure because the consequences are so great that no one", false);
		HttpEntity<Todo> entity = new HttpEntity<>(todo);
		restTemplate.exchange("http://employeews/api/employee/todos", HttpMethod.POST, entity, Boolean.class);
	}
	
	@GetMapping("/todo")
	public ResponseEntity getTodoById(@RequestParam(name="todoId", required=false) String id) {
		ResponseEntity response;
		if(id==null) {
			response = restTemplate.exchange("http://employeews/api/employee/todos",
					HttpMethod.GET, null, new ParameterizedTypeReference<List<Todo>>(){});
		} else {
			response = restTemplate.exchange("http://employeews/api/employee/todo?id={id}",
				HttpMethod.GET, null, Todo.class, Integer.parseInt(id));
		}	
		//return "It will fetch a list of todos from https://jsonplaceholder.typicode.com/todos" "http://dummy.restapiexample.com/api/v1/employees";
		return response;
	}
	
}
